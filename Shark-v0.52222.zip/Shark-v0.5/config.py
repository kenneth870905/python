bot_name = 'Shark'
# api_id = 855649
# api_hash = '34d1f9414ddfa731f281802e4d4ece1a'
# # config
# token = '' # the token from BotFather
# admin = 1409243981 # the master admin id
# admins = [1409243981] # the other admins

api_id = 1691543
api_hash = '1ce38844678e6485470816b037f1811f'
# config
token = '5231645682:AAHSAcKoL9rxIPATpbKWJ61YBUWG20-hruY' # the token from BotFather
admin =  1067001905 # the master admin id
admins = [1837963794, 1409243981, 1067001905,738714863] # the other admins


sign_time = 60
new_game_time = 90
topten_time = 10 * 60
sign_limit_balance = 1000000
reward_range = (100000, 900000)
db_file = 'data.db'
ad = """
(AD) [ad1](t.me/telegram)
"""
