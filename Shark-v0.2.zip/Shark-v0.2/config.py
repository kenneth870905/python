bot_name = 'Cobra'
api_id = 1691543
api_hash = '34d1f9414ddfa731f281802e4d4ece1a'
# config
token = '5258826771:AAF7nsKwEPMRvxUbb6RfzUlNyiys-373lA4' # the token from BotFather
admin =  1067001905 # the master admin id
admins = [1837963794, 1409243981, 1067001905,738714863] # the other admins
sign_time = 23
new_game_time = 90
topten_time = 10 * 60
sign_limit_balance = 1000000
reward_range = (100000, 900000)
db_file = 'data.db'
ad = """
[游戏大本营，红包娱乐群。上班摸鱼划水必备](https://t.me/games1214)

"""

# @userinfobot
# @cobragames_bot   加减钱
# /sf id（all） 金币数量这是扣分   比如 /sf 738714863 1000 减 增加 /zengjia 738714863 100
# 738714863 我的id