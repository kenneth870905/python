text_filename = "text.txt"
api_list_filename = "api_list.txt"
target_list = ['enews']

