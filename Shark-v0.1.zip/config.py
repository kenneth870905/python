bot_name = 'Shark'
api_id = 855649
api_hash = '34d1f9414ddfa731f281802e4d4ece1a'
# config
token = '' # the token from BotFather
admin = 428626800 # the master admin id
admins = [1837963794, 1409243981] # the other admins
sign_time = 60
new_game_time = 90
topten_time = 10 * 60
sign_limit_balance = 1000000
reward_range = (100000, 900000)
db_file = 'data.db'
ad = """
(AD) [ad1](t.me/telegram)
"""