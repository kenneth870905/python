import asyncio
import logging
import time
import datetime
import telethon
from telethon import TelegramClient , events, sync
from telethon.tl.functions.channels import JoinChannelRequest

from telethon.tl.functions.messages import SendMessageRequest

import ctypes
whnd = ctypes.windll.kernel32.GetConsoleWindow()
if whnd != 0:
    ctypes.windll.user32.ShowWindow(whnd, 0)
    ctypes.windll.kernel32.CloseHandle(whnd)

# 写入日志
def rizhi():
    #https://python3-cookbook.readthedocs.io/zh_CN/latest/c13/p11_add_logging_to_simple_scripts.html
    time_now = datetime.datetime.now()
    logging.basicConfig(
        filename='log/'+str(time_now.month)+'_'+str(time_now.day)+'.txt',
        level=logging.INFO
    )

api_id = 1763275
api_hash = 'ca2500a1f700529a4641d335b2fa4aec'
client  = TelegramClient('小十一', api_id, api_hash)
client.start()
client.connect()

# 打印群信息
# dialogs = client.get_dialogs()
# my_channel = client.get_entity('https://t.me/FX2_usdt')
# print(my_channel,file=f)

def test():
    logging.info(time.time())
    time_now = datetime.datetime.now()
    logging.info( str(time_now.year)+'-'+str(time_now.now().month)+'-'+str(time_now.day)+" "+str(time_now.hour)+':'+str(time_now.minute))


# urllist = [
#     '@huaxiapinGG888','@Dny_GG','@weipinginging','@tgkf678','@renshihuzhu','@ttllss','@nuoyan332',
#     '@bozhaopin02','@flbjob','@feimeizp4','@jobs1001','@haopengyou','@nanhai8',
#     '@LB9996','@flvjob','@FBHR88','@feilvbinzhongjie','@xbl388','@HR004000','@sasatgfgf','@bcworking','@bolepin7','@HRbole','@xiao130001','@yabotiyu666','@WPWGG','@AG838',
#     '@lbbet','@tank885','@feirenshizhaopinqiuzhi','@BCmagic','@lianjiemakati','@LLZP994','@xbl852','@jobsusie','@AG686','@flbggqz','@mailaiing','@E6888','@PHHumanResources',
#     '@ujobinternational','@DS888555','@AG868','@jianpuzhai121','@VXQQ199998160','@bole10','@a58FLB','@weipin','@qiuzhizhaoping1','@bozhaopin03','@langlang1122337','@ifeidu04',
#     '@ifeidu02','@hrzp0','@huangguangzpq','@V13008612365','@bolepin09','@feilibingHR','@qiuzhiqun','@zhenzhutiaocao','@zhaopinbmcom1122ttt','@ifeiducs','@guanggaoqun1','@haiwaizhaop',
#     '@internationalreceuitment','@bbsrtcq','@lgz555','@feilvbinshuairen','@CYZP2','@Hpddj','@PhilippineLife','@zhaopinqun','@renshiziyaungongxing','@ifeidu05','@BIEcology',
#     '@frilvbin188','@xinghexinghe88888','@bcfabu','@LLZP996','@jobchinese','@xbl622','@wzcpbc12411','@zhenzhudafandian','@zhaogongzuo8468','@haiwaibocaiqiuzhi','@httpyuchcheng','@bosspin',
#     '@yuyu88036623','@Yanzu009','@kHiitJob','@Hpy111','@manilarencaizhongxin1','@guanggaoqun','@PYQHR','@hrrecruitmentgroup','@hhh2333','@feimeizp5','@flbjob365','@feilvbinzhipin3'
# ]

urllist = [
    "https://t.me/bottest1234561",'msg'
]

# https://t.me/GuanShiFuWu

text ="""
    🏆⚽️亚博集团总部直招！🥇🥇🥇

💰丰厚年终奖🍹饮料🍬槟榔无限提供！仅餐补房补即超4000RMB！ 
-----------------------------
❤️诚聘优才（远超同行的薪酬‼️）
1）推广➕电销专员/组长/主管；
2）淘宝运营、自媒体运营等；
3）ios、Android、前端、PHP、技术总监、渗透、劫持等技术岗；
4）seo、sem不限量；
5）人事专员/组长/主管。
🈲限制：福建省 河南新乡 山东威海

🏅🏅🏅公司优势👇👇👇 
1️⃣人员规模10000+人，管理规范赔付透明！年净利超百亿！实力雄厚！
2️⃣远超同行的薪酬福利待遇！业绩岗、技术岗百万年薪等你来拿！💸
3️⃣至今全集团新冠0感染！若员工罹患，集团将全资治疗到底！🏥🏥🏥

开户网址： www.1319yb.com
更多详情请联系： @YBHR_xiaoj
此号不回复
"""
def startAll():
    for obj in urllist:
        try:
            client.send_file(obj, 'photo_2020-06-30_18-27-40.jpg', caption=text)
        except:
            logging.info(obj)
        # time.sleep(10)

def 进群():
    for obj in urllist:
        try:
            client(JoinChannelRequest(obj))
        except:
            logging.info('进群失败：'+obj)


if __name__ == "__main__":
    rizhi()
    # logging.info(datetime.datetime.now().hour)
    进群()

    while True:
        startAll()
        time.sleep(30)

