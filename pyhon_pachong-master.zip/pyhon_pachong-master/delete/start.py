# -*- coding: utf-8 -*-
# print 132
# import glob
# import json
import json
import os
import sys
import time

import datetime

from importlib import reload

from urllib.request import urlopen

reload(sys)
# sys.stdout = open('output.txt', 'w')
# os.system("pause")
# print('kaishi')

fo = open("./config.json", "r+",encoding='UTF-8')
jsonstr = fo.read()
fo.close()
jsonText = json.loads(jsonstr,encoding="UTF-8")


# jsonText = {"dirPath":"C:\\Users\\Web003\\Desktop\\删除1\\","fliterName":"LotteryPlatform_backup",'days':2,'min':3}
# jsonText = {"dirPath":"D:\\自动备份\\All\\","fliterName":"LotteryPlatform_backup",'days':2,'min':3}

#指定天数 时间戳
def getYesterday():
    today=datetime.date.today()
    # 0 表示当前  00:00
    oneday=datetime.timedelta(days=jsonText['days'])
    # 获取时间 2019-11-05 格式
    yesterday=today-oneday
    d = datetime.datetime.strptime( str(yesterday) , "%Y-%m-%d")
    t = d.timetuple()
    timeStamp = int(time.mktime(t))
    return timeStamp
    pass

def start():
    print('start')
    fileList = []
    time1 = getYesterday()
    # filepath = unicode(jsonText['dirPath'], 'utf8')
    filepath = jsonText['dirPath']
    for root, dirs, files in os.walk(filepath):
        for name in files:
            path = os.path.join(root, name)
            # 创建时间
            # time2 = os.path.getctime(path)
            # 修改时间
            xiugaiTime = os.path.getmtime(path)
            if name.find(jsonText['fliterName']) != -1:
                # and xiugaiTime<time1:
                fileList.append({'path':path,'xiugaiTime':xiugaiTime})
                # os.remove(path)
    # 排序 时间
    def cmp1(elem):
        return elem['xiugaiTime']
    fileList.sort(key=cmp1,reverse=False)
    # 删除保留 3 个
    if jsonText['min']:
        min = jsonText['min']
    else:
        min=0
    n=0
    for f in fileList:
        n = n+1
        if n <= len(fileList)-min and time1>f['xiugaiTime']:
            os.remove(f['path'])
    print('jieshu')

start()

