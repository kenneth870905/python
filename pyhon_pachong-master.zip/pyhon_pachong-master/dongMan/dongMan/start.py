# -*- coding: utf-8 -*-
import time
from multiprocessing import Process
import os
from scrapy import cmdline

while True:
    print('定时爬虫')
    os.system('scrapy crawl get1')
    # cmdline.execute('scrapy crawl get1'.split())
    time.sleep(60*12)





