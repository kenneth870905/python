# -*- coding: utf-8 -*-
# __init__.py
import copy
import os
import re
from scrapy_splash import SplashRequest
import pymysql
from pymysql.cursors import DictCursor
import scrapy
os.system("pause")

# import sys
# reload(sys)
# sys.stdout = open('output.txt', 'w')

# import logging
# logger = logging.getLogger(__name__)
# logger.info('This is a info')


class Get1Spider(scrapy.Spider):
    name = 'get1'
    allowed_domains = ['m.ac.qq.com']
    start_urls = ['https://m.ac.qq.com/category/index']

    def parse(self, response):
        # 好像是滑动
        # self.driver.swipe(300, 1000, 300, 300)
        # 爬取类别
        sql = "INSERT INTO `leibie`(`name`, `url`,`cover` ,`creationTime`) VALUES "
        for a in iter(response.css('.category-normal-item>a')):
            href = a.css('::attr(href)').extract_first()
            name = a.css('.item-name::text').extract_first().replace('| ','')
            cover = a.css('.item-cover::attr(src)').extract_first()
            sql += "('"+name+"','"+href+"','"+cover+"',NOW()),"

        sql = sql[:-1] + " ON DUPLICATE KEY UPDATE url = VALUES(url)"
        # db = pymysql.connect("localhost", "root", "123456", "tencentdongman", charset='utf8')
        db = pymysql.Connect(host='localhost',port=3307,user='root',passwd='123456',db='tencentdongman',charset='utf8')
        cursor = db.cursor(DictCursor)
        cursor.execute(sql)
        sql_1 = 'SELECT * FROM `leibie` WHERE 1'
        cursor.execute(sql_1)
        leibie_list = cursor.fetchall()
        db.close()
        # 循环列表
        for leibie in leibie_list:
            yield self.getItems(leibie,0)
            # 获取文章详情中内容  比如作者等
        db = pymysql.connect(host='localhost',port=3307,user='root',passwd='123456',db='tencentdongman',charset='utf8')
        cursor = db.cursor(DictCursor)
        sql_2 = 'SELECT * FROM `wenzhang` WHERE 1'
        cursor.execute(sql_2)
        wenzhang_list = cursor.fetchall()
        db.close()

        sql_3 = ''

        # wenzhangList

        # print '准备获取文章详情'

    def getItems(self,obj,page):

        obj = copy.copy(obj)
        url = 'https://m.ac.qq.com' + obj['url'] + '&page='+str(page)+'&pageSize=15&style=items'
        # print '文章列表',url
        return scrapy.Request(url, callback=self.wenzhangList, meta={
            'obj':obj,
            'page':page,
            'dont_redirect': True,
            }, dont_filter=True)

    def wenzhangList(self,response):
        # 文章列表
        meta = copy.copy(response.meta)
        obj = meta['obj']
        page = meta['page']
        leiBieId = obj['id']

        sql = "INSERT INTO `wenzhang`(`name` ,`cover`,`url`, `leiBieId`, `renQi`, `biaoQian`, `jianJie`, `creationTime`) VALUES "
        for li in response.css('.comic-item'):
            # 这里可以获取到 名称 简介 更新时间
            name = li.css('.comic-title::text').extract_first().replace(' ','').replace('\n','').replace("\r","")
            url = li.css('a::attr(href)').extract_first()
            renQi = li.css('.comic-hot::text').extract_first()
            if renQi:
                renQi1 = re.findall("\d+",renQi)[0]
            else:
                renQi1 = 0
            biaoQian = li.css('.comic-tag::text').extract_first()
            biaoQian = biaoQian.replace(' ','|')
            jianJie = li.css('.comic-desc::text').extract_first()
            cover = li.css('.cover-image::attr(src)').extract_first()
            sql += "('"+name+"','"+cover+"','"+url+"','"+str(leiBieId)+"','"+str(renQi1)+"','"+biaoQian+"','"+jianJie+"',NOW()),"
        sql = sql[:-1] + " ON DUPLICATE KEY UPDATE url = VALUES(url)"
        db = pymysql.connect(host='localhost',port=3307,user='root',passwd='123456',db='tencentdongman',charset='utf8')
        cursor = db.cursor(DictCursor)
        cursor.execute(sql)
        sql_1 = 'SELECT * FROM `wenzhang` WHERE 1'
        cursor.execute(sql_1)
        wenzhang_list = cursor.fetchall()

        # print '获取文章列表'
        for wenzhang in wenzhang_list:
            url = wenzhang['url']
            id=url[url.rfind('/')+1:]
            url1 = "https://m.ac.qq.com/comic/chapterList/id/"+id
            # 获取话数页面
            # print '循环文章获取话list'
            yield scrapy.Request(url1, callback=self.huaList, meta={
                'wenzhang':wenzhang,
                'dont_redirect': True,
            })


        # 循环获取下一页
        page = page+1
        url = 'https://m.ac.qq.com' + obj['url'] + '&page='+str(page)+'&pageSize=15&style=items'
        if len(response.css('.comic-item'))>14 and page<5:
            yield scrapy.Request(url, callback=self.wenzhangList, meta={
                'obj': obj,
                'page':page,
                'dont_redirect': True,
                }, dont_filter=True)

    def wenZhangXiangQing(self,response):

        pass

    def huaList(self,response):
        # print 'huaList'
        # return
        meta = copy.copy(response.meta)
        wenzhang = meta['wenzhang']
        # print '获取话列表_'+response.url
        script0 = """
                                           function main(splash)
                                               splash:set_viewport_size(375, 667)
                                               splash:go(splash.args.url)
                                               local scroll_to = splash:jsfunc("window.scrollTo")
                                               scroll_to(0, 667)
                                               splash:wait(3)
                                               return {
                                                   html = splash:html()
                                               }
                                           end"""

        wenZhangId = wenzhang['id']
        # 获取最后一话
        sql = "SELECT * FROM `hualist` WHERE `wenZhangId`='" + str(wenZhangId) + "' ORDER BY `name` DESC"
        db = pymysql.connect(host='localhost',port=3307,user='root',passwd='123456',db='tencentdongman',charset='utf8')
        cursor = db.cursor(DictCursor)
        cursor.execute(sql)
        maxHua = cursor.fetchone()
        db.close()
        # print maxHua
        if len(response.css('.chapter-list.normal .chapter-item'))>0:
            sql1 = "INSERT INTO `hualist`(`wenZhangId`, `name`, `url`, `creationTime`) VALUES "
            add = False
            for li in response.css('.chapter-list.normal .chapter-item'):
                name = li.css('a::text').extract_first()
                url = li.css('a::attr(href)').extract_first()

                if maxHua and int(name)<= int(maxHua['name']):
                    # print '已有数据'
                    pass
                else:
                    add = True
                    # print '添加数据'
                    sql1 += "('" + str(wenZhangId) + "','" + name + "','" + url + "',NOW()),"

            sql1 = sql1[:-1] + " ON DUPLICATE KEY UPDATE url = VALUES(url)"

            if add:
                db = pymysql.connect(host='localhost',port=3307,user='root',passwd='123456',db='tencentdongman',charset='utf8')
                cursor = db.cursor()
                cursor.execute(sql1)
                cursor.fetchall()
                db.close()
            else:
                # print '没有需要新添加话列表'
                pass
        else:
            pass
            # print '无话列表', response.url

        # 查询 没有 爬取的 话  这里需要优化
        sql = "SELECT hualist.*, huaimage.id AS huaimageId FROM `hualist` LEFT JOIN huaimage ON huaimage.huaId = hualist.id WHERE hualist.wenZhangId = '"+str(wenZhangId)+"' AND huaimage.id IS null"
        # sql ="SELECT * FROM `hualist` WHERE wenZhangId = "+str(wenZhangId)+" AND ( SELECT COUNT(*) FROM huaimage WHERE huaimage.huaId = hualist.id ) =0"
        db = pymysql.connect(host='localhost',port=3307,user='root',passwd='123456',db='tencentdongman',charset='utf8')
        cursor = db.cursor(DictCursor)
        cursor.execute(sql)
        list = cursor.fetchall()
        db.close()
        # print '已查询成功'
        # print '-------', list
        for huaitem in list:
            url = 'https://m.ac.qq.com'+huaitem['url']
            yield SplashRequest(url, callback=self.huaxiangqing, meta={
                    'hua':huaitem,
                    'dont_redirect': True,
                    'splash': {
                        'args': {'lua_source': script0, 'images': 0, 'wait': 3},
                        'endpoint': 'execute',
                    }
                })
        # ({u'url': u'/chapter/index/id/642093/cid/2', u'creationTime': datetime.datetime(2019, 10, 30, 16, 44, 41), u'id': 14661, u'name': 1, u'wenZhangId': 40})

    def huaxiangqing(self,response):
        # print '话', response.url
        meta = copy.copy(response.meta)
        hua = meta['hua']
        if len(response.css('.comic-pic-list img'))>0:
            sql = "INSERT INTO `huaimage`( `image`, `huaId`, `creationTime`) VALUES "
            for img in response.css('.comic-pic-list img'):
                # print '图片', img.css('::attr(data-src)').extract_first()
                image = img.css('::attr(data-src)').extract_first()
                sql += "('"+image+"','"+ str(hua['id'])+"',NOW()),"
            sql = sql[:-1]
            # print sql
            db = pymysql.connect(host='localhost',port=3307,user='root',passwd='123456',db='tencentdongman',charset='utf8')
            cursor = db.cursor()
            cursor.execute(sql)
            cursor.fetchall()
            db.close()
        else:
            # print '话详获取情获取失败_', response.url
            pass


















