# -*- coding: utf-8 -*-
from importlib import reload

import scrapy
from scrapy_splash import SplashRequest
import pymysql
import copy
import time
import datetime

import sys
reload(sys)
sys.stdout = open('output.txt', 'w')

# import logging
# logger = logging.getLogger(__name__)
# logger.info('This is a info')

class GetnewsSpider(scrapy.Spider):
    name = 'getNews'
    allowed_domains = ['qq.com']
    # 查询类型 t1
    start_urls = ['https://xw.qq.com/m/s/sort']
    print("getAll")
    def start_requests(self):
        for url in self.start_urls:
            yield SplashRequest(url, self.parse, args={'wait': '10'})

    def parse(self, response):
        ul_list = response.css(".ch-list")

        sql = "INSERT INTO `news_t1`(`name`, `creationTime` , `type`, `url`) VALUES "
        for ul in ul_list:
            for li in ul.css('li'):
                name = li.css('::text').extract_first()
                url = li.css('a::attr(href)').extract_first()
                sql += "('" + name + "',NOW() , '0' , '" + url + "'),"
        sql = sql[:-1] + " ON DUPLICATE KEY UPDATE url = VALUES(url)"

        # 链接数据库
        db = pymysql.connect("localhost", "root", "123456", "news", charset='utf8')
        cursor = db.cursor()
        cursor.execute(sql)
        db.close()
        return self.getT2()

    # 访问t1页面详情 获取T2
    def getT2(self):
        # 链接数据库
        db = pymysql.connect("localhost", "root", "123456", "news", charset='utf8')
        cursor = db.cursor()
        sql = "SELECT * FROM `news_t1` WHERE 1"
        cursor.execute(sql)
        news_t1 = cursor.fetchall()
        db.close()
        script0 = """
               function main(splash)
                   splash:set_viewport_size(375, 667)
                   splash:go(splash.args.url)
                   local scroll_to = splash:jsfunc("window.scrollTo")
                   scroll_to(0, 5000)
                   splash:wait(10)
                   return {
                       html = splash:html()
                   }
               end"""
        # print news_t1
        for row in news_t1:
            u = 'https://xw.qq.com' + row[7]
            yield SplashRequest(u, callback=self.getT2Parse, meta={
                'row': row,
                'dont_redirect': True,
                'splash': {
                    'args': {'lua_source': script0, 'images': 0, 'wait': 10},
                    'endpoint': 'execute',
                }
            }, dont_filter=True)

    # 爬取t2
    def getT2Parse(self, response):
        # print 'getT2Parse'+response.url
        meta = copy.copy(response.meta)
        row = meta['row']
        if len(response.css(".list a")) != 0:
            for a in response.css(".list a"):
                t1id = str(row[0])
                name = a.css('::text').extract_first()
                url = a.css('::attr(href)').extract_first()
                # 注意这里是两个sql语句
                sql1 = "INSERT INTO `news_t2`(`t1id`, `name`, `url`) VALUES ('" + t1id + "','" + name + "','" + url + "' ) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id) , url = VALUES(url);"
                sql2 = "SELECT LAST_INSERT_ID()"
                db = pymysql.connect("localhost", "root", "123456", "news", charset='utf8')
                cursor = db.cursor()
                cursor.execute(sql1)
                cursor.execute(sql2)
                t2id = cursor.fetchone()
                db.close()
                return self.getNewList(url, t2id[0])
        else:
            # 没有下级设置默认
            t1id = str(row[0])
            name = row[1]
            url = row[7]
            sql1 = "INSERT INTO `news_t2`(`t1id`, `name`, `url`) VALUES ('" + t1id + "','" + name + "','" + url + "' ) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id) , url = VALUES(url);"
            sql2 = "SELECT LAST_INSERT_ID();"
            db = pymysql.connect("localhost", "root", "123456", "news", charset='utf8')
            cursor = db.cursor()
            cursor.execute(sql1)
            cursor.execute(sql2)
            t2id = cursor.fetchone()
            db.close()
            return self.getNewList(row[7], t2id[0])

    def getNewList(self, url, t2id):
        # print url
        s1 = """
                           function main(splash)
                               splash:set_viewport_size(375, 667)
                               splash:go(splash.args.url)
                               local scroll_to = splash:jsfunc("window.scrollTo")
                               scroll_to(0, 5000)
                               splash:wait(10)
                               return {
                                   html = splash:html()
                               }
                           end"""
        u = 'https://xw.qq.com' + url
        yield SplashRequest(u, callback=self.newList_r,
                            meta={
                                't2id': t2id,
                                'dont_redirect': True,
                                'splash': {
                                    'args': {'lua_source': s1, 'images': 1, 'wait': 10},
                                    'endpoint': 'execute',
                                }
                            })
    # 新闻列表
    def newList_r(self,response):
        # print 'newList_r_'+response.url
        meta = copy.copy(response.meta)
        t2id = meta['t2id']
        div_list = response.css('.container.showDividingLine')
        index = 0
        for div in div_list:
            index = index + 1
            if index > 5:
                break
            o = {}
            o['t2id'] =t2id

            if div.css('.title::text'):
                o['title'] = div.css('.title::text').extract_first()
            else:
                o['title'] = ''

            if div.css('.image img'):
                o['cover'] = div.css('.image img::attr(src)').extract_first()
            elif div.css('.images img'):
                img_list = []
                for img in div.css('.images img'):
                    img_list.append(img.css("::attr(src)").extract_first())
                o['cover'] = ",".join(img_list)
            else:
                o['cover'] = ''

            root_sec = div.css('.root-sec *::text').extract()
            if '置顶' in root_sec:
                o['recommend'] = 1
            else:
                o['recommend'] = 0

            s2 = """
                   function main(splash)
                       splash:set_viewport_size(375, 667)
                       splash:go(splash.args.url)
                       local scroll_to = splash:jsfunc("window.scrollTo")
                       scroll_to(0, 5000)
                       splash:wait(10)
                       return {
                           html = splash:html()
                       }
                   end"""
            u = div.css('a::attr(href)').extract_first()
            yield SplashRequest('https://xw.qq.com' + u, callback=self.getNewsDetails,
                                meta={
                                    'o': o,
                                    'dont_redirect': True,
                                    'splash': {
                                        'args': {'lua_source': s2, 'images': 1, 'wait': 10},
                                        'endpoint': 'execute',
                                    }
                                })

    # 获取新闻详情
    def getNewsDetails(self, response):
        # print 'getNewsDetails_'+response.url
        meta = copy.copy(response.meta)
        o = meta['o']
        # 来源名称 地址
        source_name = ''
        if response.css('.author *::text'):
            source_name = response.css('.author *::text').extract_first()
        source_url=''
        if response.css('.author::attr(href)'):
            source_url = response.css('.author::attr(href)').extract_first()
        # 时间
        if response.css('#subtime::text'):
            o['time'] = response.css('#subtime::text').extract_first()
            if not self.is_valid_date(o['time']):
                o['time']=str(datetime.datetime.now().year)+'-'+o['time']
        else:
            o['time'] = ''

        if response.css('.jsx-2017720292.title').extract_first():
            o['title'] = response.css('.jsx-2017720292.title::text').extract_first()
        else:
            o['title'] = ''

        if response.css('#article_body'):
            html = response.css('#article_body').extract_first()
            o['content'] = html
        else:
            o['content'] = ''

        # 链接数据库
        db = pymysql.connect("localhost", "root", "123456", "news", charset='utf8')
        cursor = db.cursor()
        # 添加来源
        sql = "INSERT INTO `source`(`name`, `url`) VALUES ('"+source_name+"','"+source_url+"') ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id) , name = VALUES(name)"
        sql1 = "SELECT LAST_INSERT_ID();"
        cursor.execute(sql)
        cursor.execute(sql1)
        # 来源id
        ids = cursor.fetchone()

        sql2 = "INSERT INTO `news`(`title`, `content`, `cover`, `source`, `time`, `url`,`creationTime` ,`t2id`, `recommend`) VALUES " \
               "('"+o['title']+"','"+o['content']+"','"+o['cover']+"','"+str(ids[0])+"','"+o['time']+"','"+response.url+"',NOW(),'"+str(o['t2id'])+"','"+str(o['recommend'])+"') ON DUPLICATE KEY UPDATE title = VALUES(title)"
        cursor.execute(sql2)
        db.close()

        if source_url != '':
            s3 = """
               function main(splash)
                   splash:set_viewport_size(375, 667)
                   splash:go(splash.args.url)
                   local scroll_to = splash:jsfunc("window.scrollTo")
                   scroll_to(0, 50)
                   splash:wait(10)
                   return {
                       html = splash:html()
                   }
               end"""
            u = 'https://xw.qq.com' + source_url
            yield SplashRequest(u, callback=self.getSource,
                                meta={
                                    'i': ids[0],
                                    'dont_redirect': True,
                                    'splash': {
                                        'args': {'lua_source': s3, 'images': 1, 'wait': 10},
                                        'endpoint': 'execute',
                                    }
                                })

    # 目前有58条来源数据没有简介
    def getSource(self,response):
        # print 'getSource_'+response.url
        meta = copy.copy(response.meta)
        logo = ''
        if response.css('.icon div::attr(style)'):
            logo = response.css('.icon div::attr(style)').extract_first()
            logo = logo[logo.find('url(') + 4:logo.find(')')]

        introduce = ''
        if response.css('.desc::text'):
            introduce = response.css('.desc::text').extract_first()
        sql = "UPDATE `source` SET `logo`='" + logo + "',`introduce`='" + introduce + "' WHERE `id`=" + str(meta['i'])
        db = pymysql.connect("localhost", "root", "123456", "news", charset='utf8')
        cursor = db.cursor()
        cursor.execute(sql)
        db.close()

        # 判断是否不是时间字符串
    def is_valid_date(self, str):
        try:
            time.strptime(str, "%Y-%m-%d")
            return True
        except:
            return False





