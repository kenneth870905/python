# -*- coding: utf-8 -*-。
import sys
from importlib import reload
import redis

reload(sys)
sys.stdout = open('output.txt', 'w',encoding='utf8')

r = redis.Redis(host='localhost', port=6379, db=0)

# string 类型
r.set('str', '字符串类型')
str=r.get('str')
print(str)

# hash 类型
r.hset('hash','name','张三1')
r.hset('hash','性别','张三2')
hashstr = r.hget('hash','name')
print(hashstr)

hashK = r.hgetall('hash')
print(hashK)

# list 类型
# 添加一个
r.lpush('num','33','44','55')
# r.lpushx('num',)
# 添加一个 最前面
r.lpushx('num','01')
# 获取第0个
print(r.lindex('num','0'))
# 获取长度
print(r.llen('num'))

# 相关网址
# https://www.cnblogs.com/wang-yc/p/5693288.html




